#!/usr/bin/env bash
# SPEC add-in — per-user removal, run from Git Bash. Takes away exactly what
# install-ea-spec.sh put in place: files under %LOCALAPPDATA% and HKCU entries.
set -eu
export MSYS_NO_PATHCONV=1
export MSYS2_ARG_CONV_EXCL='*'

case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "This script runs on Windows, under Git Bash." >&2; exit 1 ;;
esac

CLSID='{7E1FBA1E-5A0D-4E7A-9C2B-2C43E90D5A31}'
PROGID='EASpecExporter.AddIn'
APP="$LOCALAPPDATA/Programs/SPEC"
# Name and directory from before the rename to SPEC (0.2.0) — taken along, so
# no entry is left behind in EA's add-in list.
OLD_APP="$LOCALAPPDATA/Programs/EA Spec"

if tasklist /FI "IMAGENAME eq EA.exe" 2>/dev/null | grep -q "EA.exe"; then
  echo "Enterprise Architect is running — close it and try again." >&2
  exit 1
fi

reg delete 'HKCU\Software\Sparx Systems\EAAddins\SPEC' /f >/dev/null 2>&1 || true
reg delete 'HKCU\Software\Sparx Systems\EAAddins\EASpecExporter' /f >/dev/null 2>&1 || true
reg delete "HKCU\Software\Classes\CLSID\\$CLSID" /f /reg:32 >/dev/null 2>&1 || true
reg delete "HKCU\Software\Classes\\$PROGID" /f >/dev/null 2>&1 || true
rm -rf "$APP"
[ "$OLD_APP" = "$APP" ] || rm -rf "$OLD_APP"

echo "SPEC removed. Settings and generated files are left untouched."
