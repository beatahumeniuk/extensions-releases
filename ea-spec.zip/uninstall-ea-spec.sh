#!/usr/bin/env bash
# SPEC — deinstalacja per-user z Git Bash. Zabiera wyłącznie to, co
# zainstalował install-ea-spec.sh: pliki w %LOCALAPPDATA% i wpisy w HKCU.
set -eu
export MSYS_NO_PATHCONV=1
export MSYS2_ARG_CONV_EXCL='*'

case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "Ten skrypt uruchamia się na Windows, w Git Bash." >&2; exit 1 ;;
esac

CLSID='{7E1FBA1E-5A0D-4E7A-9C2B-2C43E90D5A31}'
PROGID='EASpecExporter.AddIn'
APP="$LOCALAPPDATA/Programs/SPEC"
# Nazwa i katalog sprzed przemianowania na SPEC (0.2.0) — zabierane razem,
# żeby po deinstalacji nie został wpis na liście dodatków EA.
OLD_APP="$LOCALAPPDATA/Programs/EA Spec"

if tasklist /FI "IMAGENAME eq EA.exe" 2>/dev/null | grep -q "EA.exe"; then
  echo "Enterprise Architect jest uruchomiony — zamknij go i spróbuj ponownie." >&2
  exit 1
fi

reg delete 'HKCU\Software\Sparx Systems\EAAddins\SPEC' /f >/dev/null 2>&1 || true
reg delete 'HKCU\Software\Sparx Systems\EAAddins\EASpecExporter' /f >/dev/null 2>&1 || true
reg delete "HKCU\Software\Classes\CLSID\\$CLSID" /f /reg:32 >/dev/null 2>&1 || true
reg delete "HKCU\Software\Classes\\$PROGID" /f >/dev/null 2>&1 || true
rm -rf "$APP"
[ "$OLD_APP" = "$APP" ] || rm -rf "$OLD_APP"

echo "SPEC odinstalowany. Ustawienia i wygenerowane pliki pozostają nietknięte."
