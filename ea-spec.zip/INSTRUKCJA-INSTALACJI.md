# SPEC — instalacja (bez konta administratora)

Dodatek do Enterprise Architect 13.5 (build 1352, 32-bit). Wszystko dzieje się
per-user: pliki w `%LOCALAPPDATA%`, wpisy w HKCU — **żadnego UAC, żadnego
PowerShella**. Jedyny warunek systemowy: .NET Framework 4.7.2 (zwykle już jest
zainstalowany; jeśli nie — to prośba do administratora systemu, skrypt niczego
nie pobiera).

## 1. Pobranie

Przeglądarką:

* strona release'u: `https://github.com/beatahumeniuk/extensions-releases/releases/tag/latest-build`
  → plik **`ea-spec.zip`**,
* awaryjnie, gdyby załącznika nie było na stronie:
  `https://raw.githubusercontent.com/beatahumeniuk/extensions-releases/main/ea-spec.zip`.

## 2. Instalacja

1. Rozpakuj `ea-spec.zip` (gdziekolwiek, np. do Pobranych).
2. **Zamknij Enterprise Architect.**
3. W Git Bash, w rozpakowanym katalogu:

   ```bash
   bash install-ea-spec.sh
   ```

4. Uruchom EA. Menu dodatku: **Specialize → SPEC** (w EA 13.5:
   **Extensions → SPEC**).

Aktualizacja = te same trzy kroki na nowszym `ea-spec.zip` (pliki są
podmieniane w miejscu). Deinstalacja: `bash uninstall-ea-spec.sh`.

### Aktualizacja z 0.1.0, gdy dodatek nazywał się jeszcze „EA Spec"

**Nie odinstalowuj niczego wcześniej** — `install-ea-spec.sh` robi to sam:
kasuje wpis `EAAddins\EASpecExporter` (zostawiony pokazałby dodatek na liście
EA drugi raz) i stary katalog `%LOCALAPPDATA%\Programs\EA Spec`. Ustawienia
przenoszą się same: przy braku nowego pliku dodatek czyta raz stary
`settings.json`, więc folder szablonów, katalog roboczy i ścieżka Excela
zostają.

Jeden wyjątek: jeśli poprzednia wersja przyszła z instalatora **.exe**, skrypt
rozpozna to po `unins000.exe` w starym katalogu i katalogu **nie usunie** —
wtedy usuń „EA Spec" z *Aplikacje i funkcje* Windows. Dodatek działa już
wtedy z nowego katalogu, więc kolejność nie ma znaczenia.

Osobna sprawa, nie instalacyjna: 0.2.0 czyta wyłącznie tagi `Spec.*`. Element
otagowany pod 0.1.0 (`EASpec.*`) będzie dla dodatku nieotagowany — trzeba go
przetagować.

## 3. Szablony firmowe specyfikacji

Szablony (`rest.docx`, `soa.docx`, `event.docx`) **nie jadą w paczce** — mają
logo organizacji i nie mają czego szukać w publicznym repozytorium. Dostajesz je
osobno (czat / mail do samej siebie).

1. Skopiuj wszystkie trzy pliki do jednego folderu na dysku, np.
   `C:\Users\<login>\Documents\EA-Spec-szablony\`. Nazwy plików muszą zostać:
   `rest.docx`, `soa.docx`, `event.docx` — dodatek dobiera plik po rodzaju
   usługi (SOAP → `soa.docx`, event → `event.docx`, reszta → `rest.docx`).
2. W EA: **SPEC → Ustawienia** → pole
   **„Folder szablonów firmowych (rest.docx / soa.docx / event.docx)"** →
   wskaż ten folder.
3. Przy okazji w tym samym oknie ustaw:
   * **Katalog roboczy (pliki wynikowe)** — dokąd mają trafiać wygenerowane
     specyfikacje i kontrakty,
   * **Excel z mapowaniem nazw (WSDL/XSD)** — Twój skoroszyt skrótów
     (kolumna A: nazwa w modelu, kolumna B: nazwa docelowa),
   * opcjonalnie **Pakiet główny słowników**.

Bez ustawionego folderu szablonów dodatek generuje układ wbudowany (ta sama
treść, bez brandingu). Brak któregoś z trzech plików w folderze to jawny błąd
`DOCX_TEMPLATE_MISSING` — nigdy cicha podmiana.

To zwykłe dokumenty Worda ze znacznikami `{{...}}` i kontrolkami treści
`cd:*` — ten sam komplet obsługuje każde narzędzie, które tę składnię
rozumie, więc jeden folder szablonów wystarcza.

## 4. Skąd wiadomo, że jest nowa wersja

Opis release'u `latest-build` niesie datę builda i commit źródłowy; wersja
SPEC leży w `ea-spec-version.txt` obok paczki i w pliku `WERSJA.txt`
wewnątrz `ea-spec.zip`.
