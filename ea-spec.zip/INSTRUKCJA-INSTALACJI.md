# EA Spec — instalacja na komputerze służbowym (bez konta admina)

Dodatek do Enterprise Architect 13.5 (build 1352, 32-bit). Wszystko dzieje się
per-user: pliki w `%LOCALAPPDATA%`, wpisy w HKCU — **żadnego UAC, żadnego
PowerShella**. Jedyny warunek systemowy: .NET Framework 4.7.2 (na maszynach
firmowych zwykle już jest; jeśli nie — to prośba do IT, skrypt niczego nie
pobiera).

## 1. Pobranie

Przeglądarką (ona zna firmowe proxy):

* strona release'u: `https://github.com/beatahumeniuk/extensions-releases/releases/tag/latest-build`
  → plik **`ea-spec.zip`**,
* awaryjnie, gdyby załącznika nie było na stronie:
  `https://raw.githubusercontent.com/beatahumeniuk/extensions-releases/main/ea-spec.zip`.

## 2. Instalacja

1. Rozpakuj `ea-spec.zip` (gdziekolwiek, np. do Pobranych).
2. **Zamknij Enterprise Architect.**
3. W Git Bash, w rozpakowanym katalogu:

   ```bash
   bash install-ea-spec.sh
   ```

4. Uruchom EA. Menu dodatku: **Specialize → EA Spec** (w EA 13.5:
   **Extensions → EA Spec**).

Aktualizacja = te same trzy kroki na nowszym `ea-spec.zip` (pliki są
podmieniane w miejscu). Deinstalacja: `bash uninstall-ea-spec.sh`.

## 3. Szablony firmowe specyfikacji

Szablony (`rest.docx`, `soa.docx`, `event.docx`) **nie jadą w paczce** — mają
logo CA i nie mają czego szukać w publicznym repozytorium. Dostajesz je
osobno (czat / mail do samej siebie).

1. Skopiuj wszystkie trzy pliki do jednego folderu na dysku, np.
   `C:\Users\<login>\Documents\EA-Spec-szablony\`. Nazwy plików muszą zostać:
   `rest.docx`, `soa.docx`, `event.docx` — dodatek dobiera plik po rodzaju
   usługi (SOAP → `soa.docx`, event → `event.docx`, reszta → `rest.docx`).
2. W EA: **EA Spec → Settings** → pole
   **„Folder szablonów firmowych (rest.docx / soa.docx / event.docx)"** →
   wskaż ten folder.
3. Przy okazji w tym samym oknie ustaw:
   * **Katalog roboczy (pliki wynikowe)** — dokąd mają trafiać wygenerowane
     specyfikacje i kontrakty,
   * **Excel z mapowaniem nazw (WSDL/XSD)** — Twój skoroszyt skrótów
     (kolumna A: nazwa w modelu, kolumna B: nazwa docelowa),
   * opcjonalnie **Pakiet główny KMD**.

Bez ustawionego folderu szablonów dodatek generuje układ wbudowany (ta sama
treść, bez brandingu). Brak któregoś z trzech plików w folderze to jawny błąd
`DOCX_TEMPLATE_MISSING` — nigdy cicha podmiana.

Te same trzy pliki obsługują api-designera (profil `docx.json` →
`templates`), więc jeden komplet szablonów wystarczy dla obu narzędzi.

## 4. Skąd wiadomo, że jest nowa wersja

Opis release'u `latest-build` niesie datę builda i commit źródłowy; wersja
EA Spec leży w `ea-spec-version.txt` obok paczki i w pliku `WERSJA.txt`
wewnątrz `ea-spec.zip`.
