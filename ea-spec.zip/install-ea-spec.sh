#!/usr/bin/env bash
# SPEC add-in — per-user setup, run from Git Bash on Windows. Everything it
# needs sits next to this script.
#
# What it does:
#   * copies the add-in files to %LOCALAPPDATA%\Programs\SPEC,
#   * registers the COM class under HKCU (32-bit view — EA is 32-bit),
#   * adds the add-in under HKCU\Software\Sparx Systems\EAAddins as SPEC,
#   * clears the entry left by the previous name so EA does not list the
#     add-in twice — see the "previous name" section below.
# The same entries the Inno Setup installer writes (EA-Spec-Exporter.iss).
#
# Run:        bash install-ea-spec.sh
# Remove:     bash uninstall-ea-spec.sh
set -eu

# reg.exe takes /v /d /f arguments that Git Bash must not rewrite into
# paths. These two variables switch that conversion off for everything below.
export MSYS_NO_PATHCONV=1
export MSYS2_ARG_CONV_EXCL='*'

case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "This script runs on Windows, under Git Bash." >&2; exit 1 ;;
esac

here="$(cd "$(dirname "$0")" && pwd)"
CLSID='{7E1FBA1E-5A0D-4E7A-9C2B-2C43E90D5A31}'
PROGID='EASpecExporter.AddIn'
ASSEMBLY='EASpecExporter.AddIn, Version=0.4.5.0, Culture=neutral, PublicKeyToken=null'
APP="$LOCALAPPDATA/Programs/SPEC"
# Name and directory from before the rename to SPEC (0.2.0). The ProgId and
# the assembly names stay — EA never shows them, so there is nothing to change.
OLD_APP="$LOCALAPPDATA/Programs/EA Spec"
OLD_ADDIN_KEY='HKCU\Software\Sparx Systems\EAAddins\EASpecExporter'

if [ ! -d "$here/addin" ]; then
  echo "No addin/ directory next to this script — unpack the whole archive and" >&2
  echo "run the script from the unpacked directory." >&2
  exit 1
fi

# EA has to be closed for the DLL replacement to be clean.
if tasklist /FI "IMAGENAME eq EA.exe" 2>/dev/null | grep -q "EA.exe"; then
  echo "Enterprise Architect is running — close it and try again." >&2
  exit 1
fi

# .NET Framework 4.7.2 (Release >= 461808). Reading HKLM needs no elevation;
# installing the framework does, and that is not this script's job.
release="$(reg query 'HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' /v Release 2>/dev/null \
  | tr -d '\r' | awk '$1 == "Release" { print $3 }')"
if [ -z "${release:-}" ] || [ "$((release))" -lt 461808 ]; then
  echo "This add-in needs .NET Framework 4.7.2. Nothing is downloaded or" >&2
  echo "installed here — get 4.7.2 in place and come back." >&2
  exit 1
fi

echo "== files =="
mkdir -p "$APP"
cp -f "$here"/addin/* "$APP"/
appwin="$(cygpath -w "$APP")"
echo "   $appwin"

echo "== COM registration (per-user, 32-bit view) =="
ckey="HKCU\Software\Classes\CLSID\\$CLSID"
reg add "$ckey" /ve /d "SPEC Add-In" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /ve /d "mscoree.dll" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v ThreadingModel /d "Both" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Class /d "EASpecExporter.AddIn.AddInMain" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Assembly /d "$ASSEMBLY" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v RuntimeVersion /d "v4.0.30319" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v CodeBase /d "file:///$appwin\EASpecExporter.AddIn.dll" /f /reg:32 >/dev/null
reg add "$ckey\ProgId" /ve /d "$PROGID" /f /reg:32 >/dev/null
reg add "HKCU\Software\Classes\\$PROGID" /ve /d "SPEC Add-In" /f >/dev/null
reg add "HKCU\Software\Classes\\$PROGID\CLSID" /ve /d "$CLSID" /f >/dev/null

echo "== EA add-in entry =="
# 32-bit EA reads EAAddins (not EAAddins64). The key name is what EA shows in
# its add-in list — hence SPEC.
reg add 'HKCU\Software\Sparx Systems\EAAddins\SPEC' /ve /d "$PROGID" /f >/dev/null

echo "== previous name =="
# The entry under the old name points at the same ProgId, so leaving it would
# list the add-in a second time, as "EASpecExporter".
reg delete "$OLD_ADDIN_KEY" /f >/dev/null 2>&1 && echo "   removed the EASpecExporter entry" || true
# The old directory holds files put there by the previous setup; the registry
# already points at the new one, so those are dead copies of the DLLs. One
# exception: when the previous version came from the Inno installer, its
# unins000.exe lives there. Deleting it would leave an entry in Apps &
# features that can no longer be uninstalled — so the directory stays, and
# removing it is left to Windows.
if [ -d "$OLD_APP" ] && [ "$OLD_APP" != "$APP" ]; then
  if [ -e "$OLD_APP/unins000.exe" ]; then
    echo "   the previous version came from the .exe installer — keeping its directory"
    echo "   remove \"EA Spec\" from Apps & features; the add-in already runs from the new directory"
  else
    rm -rf "$OLD_APP" && echo "   removed $(cygpath -w "$OLD_APP")"
  fi
fi
echo "   settings are kept — the add-in reads them from the old path once and stores them under SPEC"

echo
echo "Done. Start Enterprise Architect — the add-in menu is Specialize -> SPEC"
echo "(EA 13.5: Extensions -> SPEC). Paths and options: SPEC -> Settings."
