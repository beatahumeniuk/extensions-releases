#!/usr/bin/env bash
# SPEC — instalacja per-user z Git Bash na Windows. Bez konta admina,
# bez PowerShella, bez sieci: wszystko, czego trzeba, leży obok tego skryptu.
#
# Co robi:
#   * kopiuje pliki dodatku do %LOCALAPPDATA%\Programs\SPEC,
#   * rejestruje klasę COM per-user (HKCU, widok 32-bitowy — EA jest 32-bitowe),
#   * dopisuje dodatek pod HKCU\Software\Sparx Systems\EAAddins jako SPEC,
#   * sprząta po poprzedniej nazwie (EA Spec), żeby EA nie pokazywał dodatku
#     dwa razy — patrz sekcja „stara nazwa" niżej.
# Dokładnie te same wpisy co instalator Inno Setup (EA-Spec-Exporter.iss).
#
# Uruchomienie (Git Bash):  bash install-ea-spec.sh
# Deinstalacja:             bash uninstall-ea-spec.sh
set -eu

# reg.exe dostaje argumenty /v /d /f — Git Bash nie może ich przepisywać na
# ścieżki. Te dwie zmienne wyłączają tę konwersję dla wszystkiego poniżej.
export MSYS_NO_PATHCONV=1
export MSYS2_ARG_CONV_EXCL='*'

case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "Ten skrypt uruchamia się na Windows, w Git Bash." >&2; exit 1 ;;
esac

here="$(cd "$(dirname "$0")" && pwd)"
CLSID='{7E1FBA1E-5A0D-4E7A-9C2B-2C43E90D5A31}'
PROGID='EASpecExporter.AddIn'
ASSEMBLY='EASpecExporter.AddIn, Version=0.4.2.0, Culture=neutral, PublicKeyToken=null'
APP="$LOCALAPPDATA/Programs/SPEC"
# Nazwa i katalog sprzed przemianowania na SPEC (0.2.0). ProgId i nazwy
# zestawów zostają — EA ich nie pokazuje, więc nie ma czego zmieniać.
OLD_APP="$LOCALAPPDATA/Programs/EA Spec"
OLD_ADDIN_KEY='HKCU\Software\Sparx Systems\EAAddins\EASpecExporter'

if [ ! -d "$here/addin" ]; then
  echo "Nie widzę katalogu addin/ obok skryptu — rozpakuj cały ea-spec.zip i" >&2
  echo "uruchom skrypt z rozpakowanego katalogu." >&2
  exit 1
fi

# EA musi być zamknięty, żeby podmiana DLL była czysta.
if tasklist /FI "IMAGENAME eq EA.exe" 2>/dev/null | grep -q "EA.exe"; then
  echo "Enterprise Architect jest uruchomiony — zamknij go i spróbuj ponownie." >&2
  exit 1
fi

# .NET Framework 4.7.2 (Release >= 461808). Odczyt HKLM nie wymaga admina;
# doinstalowanie — tak, i to jest sprawa dla administratora systemu, nie tego skryptu.
release="$(reg query 'HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' /v Release 2>/dev/null \
  | tr -d '\r' | awk '$1 == "Release" { print $3 }')"
if [ -z "${release:-}" ] || [ "$((release))" -lt 461808 ]; then
  echo "Ten dodatek wymaga .NET Framework 4.7.2. Nic nie pobieram i nie" >&2
  echo "instaluję sam — poproś administratora systemu o .NET Framework 4.7.2 i wróć tutaj." >&2
  exit 1
fi

echo "== pliki =="
mkdir -p "$APP"
cp -f "$here"/addin/* "$APP"/
appwin="$(cygpath -w "$APP")"
echo "   $appwin"

echo "== rejestracja COM (per-user, widok 32-bitowy) =="
ckey="HKCU\Software\Classes\CLSID\\$CLSID"
reg add "$ckey" /ve /d "SPEC Add-In" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /ve /d "mscoree.dll" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v ThreadingModel /d "Both" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Class /d "EASpecExporter.AddIn.AddInMain" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Assembly /d "$ASSEMBLY" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v RuntimeVersion /d "v4.0.30319" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v CodeBase /d "file:///$appwin\EASpecExporter.AddIn.dll" /f /reg:32 >/dev/null
reg add "$ckey\ProgId" /ve /d "$PROGID" /f /reg:32 >/dev/null
reg add "HKCU\Software\Classes\\$PROGID" /ve /d "SPEC Add-In" /f >/dev/null
reg add "HKCU\Software\Classes\\$PROGID\CLSID" /ve /d "$CLSID" /f >/dev/null

echo "== wpis dodatku EA =="
# 32-bitowe EA czyta EAAddins (nie EAAddins64). Nazwa klucza jest tym, co EA
# pokazuje na liście dodatków — stąd SPEC.
reg add 'HKCU\Software\Sparx Systems\EAAddins\SPEC' /ve /d "$PROGID" /f >/dev/null

echo "== stara nazwa =="
# Wpis spod poprzedniej nazwy wskazuje ten sam ProgId, więc zostawiony
# pokazałby dodatek na liście EA drugi raz, jako „EASpecExporter".
reg delete "$OLD_ADDIN_KEY" /f >/dev/null 2>&1 && echo "   usunięty wpis EASpecExporter" || true
# Stary katalog to pliki położone tu przez poprzednią instalację; rejestr
# wskazuje już nowy, więc te zostają jako martwe kopie DLL. Wyjątek: gdy
# poprzednia wersja przyszła z instalatora Inno, leży tam jego unins000.exe.
# Skasowanie go zostawiłoby w „Aplikacje i funkcje" wpis, którego nie da się
# już odinstalować — wtedy katalog zostaje, a odinstalowanie należy do Windows.
if [ -d "$OLD_APP" ] && [ "$OLD_APP" != "$APP" ]; then
  if [ -e "$OLD_APP/unins000.exe" ]; then
    echo "   poprzednia wersja pochodzi z instalatora .exe — katalog zostawiam"
    echo "   odinstaluj „EA Spec” z Aplikacji i funkcji Windows — dodatek dziala juz z nowego katalogu"
  else
    rm -rf "$OLD_APP" && echo "   usunięty katalog $(cygpath -w "$OLD_APP")"
  fi
fi
echo "   ustawienia zostają — dodatek przeczyta je ze starej ścieżki raz i zapisze pod SPEC"

echo
echo "Gotowe. Uruchom Enterprise Architect — menu dodatku: Specialize → SPEC"
echo "(w EA 13.5: Extensions → SPEC). Folder szablonów firmowych wskażesz"
echo "w SPEC → Ustawienia; szczegóły w INSTRUKCJA-INSTALACJI.md."
