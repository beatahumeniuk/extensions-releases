#!/usr/bin/env bash
# EA Spec — instalacja per-user z Git Bash na Windows. Bez konta admina,
# bez PowerShella, bez sieci: wszystko, czego trzeba, leży obok tego skryptu.
#
# Co robi:
#   * kopiuje pliki dodatku do %LOCALAPPDATA%\Programs\EA Spec,
#   * rejestruje klasę COM per-user (HKCU, widok 32-bitowy — EA jest 32-bitowe),
#   * dopisuje dodatek pod HKCU\Software\Sparx Systems\EAAddins.
# Dokładnie te same wpisy co instalator Inno Setup (EA-Spec-Exporter.iss).
#
# Uruchomienie (Git Bash):  bash install-ea-spec.sh
# Deinstalacja:             bash uninstall-ea-spec.sh
set -eu

# reg.exe dostaje argumenty /v /d /f — Git Bash nie może ich przepisywać na
# ścieżki. Te dwie zmienne wyłączają tę konwersję dla wszystkiego poniżej.
export MSYS_NO_PATHCONV=1
export MSYS2_ARG_CONV_EXCL='*'

case "$(uname -s)" in
  MINGW*|MSYS*|CYGWIN*) ;;
  *) echo "Ten skrypt uruchamia się na Windows, w Git Bash." >&2; exit 1 ;;
esac

here="$(cd "$(dirname "$0")" && pwd)"
CLSID='{7E1FBA1E-5A0D-4E7A-9C2B-2C43E90D5A31}'
PROGID='EASpecExporter.AddIn'
ASSEMBLY='EASpecExporter.AddIn, Version=0.1.0.0, Culture=neutral, PublicKeyToken=null'
APP="$LOCALAPPDATA/Programs/EA Spec"

if [ ! -d "$here/addin" ]; then
  echo "Nie widzę katalogu addin/ obok skryptu — rozpakuj cały ea-spec.zip i" >&2
  echo "uruchom skrypt z rozpakowanego katalogu." >&2
  exit 1
fi

# EA musi być zamknięty, żeby podmiana DLL była czysta.
if tasklist /FI "IMAGENAME eq EA.exe" 2>/dev/null | grep -q "EA.exe"; then
  echo "Enterprise Architect jest uruchomiony — zamknij go i spróbuj ponownie." >&2
  exit 1
fi

# .NET Framework 4.7.2 (Release >= 461808). Odczyt HKLM nie wymaga admina;
# doinstalowanie — tak, i to jest sprawa dla administratora systemu, nie tego skryptu.
release="$(reg query 'HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' /v Release 2>/dev/null \
  | tr -d '\r' | awk '$1 == "Release" { print $3 }')"
if [ -z "${release:-}" ] || [ "$((release))" -lt 461808 ]; then
  echo "Ten dodatek wymaga .NET Framework 4.7.2. Nic nie pobieram i nie" >&2
  echo "instaluję sam — poproś administratora systemu o .NET Framework 4.7.2 i wróć tutaj." >&2
  exit 1
fi

echo "== pliki =="
mkdir -p "$APP"
cp -f "$here"/addin/* "$APP"/
appwin="$(cygpath -w "$APP")"
echo "   $appwin"

echo "== rejestracja COM (per-user, widok 32-bitowy) =="
ckey="HKCU\Software\Classes\CLSID\\$CLSID"
reg add "$ckey" /ve /d "EA Spec Add-In" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /ve /d "mscoree.dll" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v ThreadingModel /d "Both" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Class /d "EASpecExporter.AddIn.AddInMain" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v Assembly /d "$ASSEMBLY" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v RuntimeVersion /d "v4.0.30319" /f /reg:32 >/dev/null
reg add "$ckey\InprocServer32" /v CodeBase /d "file:///$appwin\EASpecExporter.AddIn.dll" /f /reg:32 >/dev/null
reg add "$ckey\ProgId" /ve /d "$PROGID" /f /reg:32 >/dev/null
reg add "HKCU\Software\Classes\\$PROGID" /ve /d "EA Spec Add-In" /f >/dev/null
reg add "HKCU\Software\Classes\\$PROGID\CLSID" /ve /d "$CLSID" /f >/dev/null

echo "== wpis dodatku EA =="
# 32-bitowe EA czyta EAAddins (nie EAAddins64).
reg add 'HKCU\Software\Sparx Systems\EAAddins\EASpecExporter' /ve /d "$PROGID" /f >/dev/null

echo
echo "Gotowe. Uruchom Enterprise Architect — menu dodatku: Specialize → EA Spec"
echo "(w EA 13.5: Extensions → EA Spec). Folder szablonów firmowych wskażesz"
echo "w EA Spec → Settings; szczegóły w INSTRUKCJA-INSTALACJI.md."
