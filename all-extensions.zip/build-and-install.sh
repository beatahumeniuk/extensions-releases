#!/usr/bin/env bash
#
# Installs the VS Code extension packages from this repository.
#
# Published as build-and-install.sh (the name the documentation uses), so
# every message below names the file by what it is actually called.
#
#   bash build-and-install.sh              install everything that is out of date
#   bash build-and-install.sh logic-spec   install only the named packages
#   bash build-and-install.sh --local      install .vsix files sitting next to this script
#   FORCE=1 bash build-and-install.sh      reinstall even what is already current
#
# Needs curl (or wget) and the VS Code CLI. No Node.js, no npm.

set -uo pipefail

SELF="$(basename "$0")"

REPO="${REPO:-beatahumeniuk/extensions-releases}"
BRANCH="${BRANCH:-main}"
BASE_URL="${BASE_URL:-https://raw.githubusercontent.com/$REPO/$BRANCH}"

# On Windows/Git Bash a C:/... path is understood by both bash and the CLI,
# while an MSYS /c/... path is not.
ROOT="$(cd "$(dirname "$0")" && { pwd -W 2>/dev/null || pwd; })"

usage() {
  cat <<EOF
$SELF [--download|--local] [name ...]

  --download   (default) fetch the packages over HTTPS and install them
  --local      install the .vsix files next to this script (or in LOCAL_DIR)

Without names all packages are covered; names narrow it down.

Environment:
  FORCE=1         install even when the same version is already present
  EDITOR_CLI=...  path to the VS Code CLI when autodetection fails
  LOCAL_DIR=...   directory holding the .vsix files (--local only)
  REPO=, BRANCH=  where to fetch the packages from
EOF
}

MODE=download
ARGS=()
for arg in "$@"; do
  case "$arg" in
    --download) MODE=download ;;
    --local)    MODE=local ;;
    -h|--help)  usage; exit 0 ;;
    -*)         echo "Unknown option: $arg" >&2; usage >&2; exit 2 ;;
    *)          ARGS+=("$arg") ;;
  esac
done
if [[ ${#ARGS[@]} -gt 0 ]]; then set -- "${ARGS[@]}"; else set --; fi

# An interrupted download must not leave its temp directory behind.
DL_TMP=""
trap '[[ -n "$DL_TMP" && -d "$DL_TMP" ]] && rm -rf "$DL_TMP"' EXIT

EDITOR_CLI="${EDITOR_CLI:-}"
if [[ -z "$EDITOR_CLI" ]]; then
  for c in \
    "${LOCALAPPDATA:-}/Programs/Microsoft VS Code/bin/code.cmd" \
    "${PROGRAMFILES:-}/Microsoft VS Code/bin/code.cmd" \
    "/c/Program Files/Microsoft VS Code/bin/code.cmd" \
    "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code" \
    "$HOME/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"; do
    [[ -f "$c" ]] && EDITOR_CLI="$c" && break
  done
  if [[ -z "$EDITOR_CLI" ]] && command -v code >/dev/null 2>&1; then
    EDITOR_CLI=code
  fi
  if [[ -z "$EDITOR_CLI" ]]; then
    echo "VS Code CLI not found. Set EDITOR_CLI=..." >&2
    exit 1
  fi
fi

fetch_to_stdout() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL "$1"
  elif command -v wget >/dev/null 2>&1; then wget -qO- "$1"
  else echo "curl or wget is required." >&2; return 1
  fi
}

fetch_to_file() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL -o "$2" "$1"
  else wget -qO "$2" "$1"
  fi
}

wanted() {
  local a
  [[ $# -eq 1 ]] && return 0
  local name="$1"; shift
  for a in "$@"; do [[ "$a" == "$name" ]] && return 0; done
  return 1
}

summary() {
  echo ""
  echo "──────────── summary ────────────"
  local line
  for line in "${OK[@]:-}";      do [[ -n "$line" ]] && echo "  + $line"; done
  for line in "${SKIPPED[@]:-}"; do [[ -n "$line" ]] && echo "  · $line — unchanged"; done
  for line in "${FAILED[@]:-}";  do [[ -n "$line" ]] && echo "  x $line"; done
  [[ ${#OK[@]} -eq 0 ]] || echo "
Reload the VS Code window (Ctrl+Shift+P -> Developer: Reload Window)."
}

OK=() ; SKIPPED=() ; FAILED=()

# ── Default mode: fetch the packages and install them ───────────────────────

# Whether version $1 is older than $2 (x.y.z, numerically). Bash 3.2: no sort -V.
version_lt() {
  local a="$1" b="$2" i x y
  local IFS=.
  local -a pa=($a) pb=($b)
  for i in 0 1 2 3; do
    x="${pa[$i]:-0}"; y="${pb[$i]:-0}"
    x="${x%%[^0-9]*}"; y="${y%%[^0-9]*}"
    (( 10#${x:-0} < 10#${y:-0} )) && return 0
    (( 10#${x:-0} > 10#${y:-0} )) && return 1
  done
  return 1
}

download_and_install() {
  local manifest installed tmp rc=0 name id ver asset have

  echo "Reading the version list from $REPO..."
  # A download can fail for reasons no script can fix. Packages already on
  # disk are still worth installing, so fall through to the local mode
  # instead of ending with nothing.
  # A timestamp in the address gets past the raw.githubusercontent.com cache:
  # without it a stale list came for minutes after a release and the
  # installer downgraded the extensions (2026-10-06).
  manifest="$(fetch_to_stdout "$BASE_URL/versions.txt?t=$(date +%s)")" || {
    echo "x Could not fetch $BASE_URL/versions.txt" >&2
    echo "  Looking for packages on disk..." >&2
    echo "" >&2
    install_local "$@"
    return $?
  }
  [[ -n "$manifest" ]] || { echo "x $REPO holds no packages." >&2; return 1; }

  installed=""
  if [[ "${FORCE:-0}" != "1" ]]; then
    installed="$("$EDITOR_CLI" --list-extensions --show-versions 2>/dev/null | tr -d '\r' || true)"
  fi

  tmp="$(mktemp -d)" ; DL_TMP="$tmp"

  while IFS='|' read -r name id ver asset; do
    [[ -n "${name:-}" && -n "${asset:-}" ]] || continue
    wanted "$name" "$@" || continue

    if [[ -n "$installed" ]] && grep -qixF "$id@$ver" <<<"$installed"; then
      echo "· $name $ver — already current"
      SKIPPED+=("$name $ver")
      continue
    fi

    have="$(grep -i "^$id@" <<<"$installed" | head -1 || true)"
    # Never older over newer: the list may be stale (a cache) and the
    # installed one built locally. FORCE=1 forces it.
    if [[ -n "$have" ]] && version_lt "$ver" "${have#*@}"; then
      echo "· $name: installed ${have#*@} is newer than $ver in the packages — skipped (FORCE=1 forces it)"
      SKIPPED+=("$name ${have#*@}")
      continue
    fi
    if [[ -n "$have" ]]; then
      echo "> $name: ${have#*@} -> $ver"
    else
      echo "> $name: new, $ver"
    fi

    if ! fetch_to_file "$BASE_URL/$asset?t=$(date +%s)" "$tmp/$asset"; then
      echo "  x download failed" >&2
      FAILED+=("$name (download)")
      continue
    fi

    if "$EDITOR_CLI" --install-extension "$tmp/$asset" --force; then
      OK+=("$name $ver")
    else
      FAILED+=("$name (install)")
    fi
  done <<<"$manifest"

  rm -rf "$tmp"
  # Names that match nothing in versions.txt would otherwise end in an empty
  # summary and a green exit — the same report --local gives.
  if [[ $# -gt 0 && ${#OK[@]} -eq 0 && ${#SKIPPED[@]} -eq 0 && ${#FAILED[@]} -eq 0 ]]; then
    echo "x None of the given names is in $REPO: $*" >&2
    echo "  Known packages: $(cut -d'|' -f1 <<<"$manifest" | tr '\n' ' ')" >&2
    return 1
  fi
  summary
  [[ ${#FAILED[@]} -eq 0 ]] || rc=1
  return $rc
}

# ── Local mode: install the .vsix files already on disk ─────────────────────

# Where packages may lie: an explicit directory alone, or else the script's
# own directory, the current directory and Downloads — including the
# subdirectories Windows creates when an archive is unpacked. One per line.
local_dirs() {
  local d dl seen=""
  if [[ -n "${LOCAL_DIR:-}" ]]; then
    echo "${LOCAL_DIR%/}"
    return 0
  fi
  for dl in "${USERPROFILE:-}/Downloads" "$HOME/Downloads"; do
    [[ -d "$dl" ]] && break
  done
  for d in "$ROOT" "$PWD" "$dl" "$dl"/*/; do
    [[ -n "$d" && -d "$d" ]] || continue
    d="${d%/}"
    ls "$d"/*.vsix >/dev/null 2>&1 || continue
    case "$seen" in *"|$d|"*) continue ;; esac
    seen="$seen|$d|"
    echo "$d"
  done
}

# The version a .vsix carries, when unzip is at hand.
vsix_version() {
  command -v unzip >/dev/null 2>&1 || return 0
  unzip -p "$1" extension/package.json 2>/dev/null | sed -n 's/^ *"version": *"\([^"]*\)".*/\1/p' | head -n 1
}

# Each extension once, from its newest file wherever it lies: an older
# package left in Downloads or in an earlier unpacked folder never wins
# over the one just downloaded (owner, 2026-10-15: „ładuję ją do VSC
# i mam ciągle 186").
install_local() {
  local rc=0 d f name names="" newest ver
  local dirs
  dirs="$(local_dirs)"

  if [[ -n "${LOCAL_DIR:-}" ]] && ! ls "${LOCAL_DIR}"/*.vsix >/dev/null 2>&1; then
    echo "x No .vsix file in LOCAL_DIR:" >&2
    echo "  $LOCAL_DIR" >&2
    return 1
  fi
  if [[ -z "$dirs" ]]; then
    echo "x No .vsix file found." >&2
    echo "  Looked in: this script's directory, the current directory, Downloads." >&2
    echo "  Name one directly: LOCAL_DIR=/path bash $SELF --local" >&2
    return 1
  fi

  while IFS= read -r d; do
    for f in "$d"/*.vsix; do
      [[ -f "$f" ]] || continue
      name="$(basename "$f" .vsix)"
      case "$names" in *"|$name|"*) ;; *) names="$names|$name|" ;; esac
    done
  done <<EOF_DIRS
$dirs
EOF_DIRS

  local -a list
  IFS='|' read -r -a list <<< "$names"
  for name in "${list[@]}"; do
    [[ -n "$name" ]] || continue
    wanted "$name" "$@" || continue
    newest=""
    while IFS= read -r d; do
      f="$d/$name.vsix"
      [[ -f "$f" ]] || continue
      if [[ -z "$newest" || "$f" -nt "$newest" ]]; then newest="$f"; fi
    done <<EOF_DIRS
$dirs
EOF_DIRS
    ver="$(vsix_version "$newest")"
    echo "> $name${ver:+ $ver}"
    echo "  $newest"
    if "$EDITOR_CLI" --install-extension "$newest" --force; then
      OK+=("$name${ver:+ $ver}")
    else
      FAILED+=("$name")
    fi
  done

  if [[ ${#OK[@]} -eq 0 && ${#FAILED[@]} -eq 0 ]]; then
    echo "x Packages found, but none match the given names." >&2
    return 1
  fi

  summary
  [[ ${#FAILED[@]} -eq 0 ]] || rc=1
  return $rc
}

if [[ "$MODE" == "local" ]]; then
  install_local "$@"
else
  download_and_install "$@"
fi
exit $?
